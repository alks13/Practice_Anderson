'use strict';

const xhr = new XMLHttpRequest;
xhr.open('GET',     "http://api.tvmaze.com/schedule/full");
xhr.responseType = 'json';
xhr.send();
const SUCCESS_STATUS = 200;

function handleXHR() {

    // Если статус не 200, тогда уведомляем пользователя и прекращаем шоу.
    if (xhr.status !== SUCCESS_STATUS) {
        alert('Error');
        return;
    }

    // Если данные получены - находим наш список и начинаем его наполнять
    const list = document.querySelector('.movie');
    const movies = xhr.response.results;






// когда данные получены - вызываем нашу функцию
xhr.onload = handleXHR;
